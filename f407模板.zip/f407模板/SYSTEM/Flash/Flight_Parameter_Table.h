#ifndef _FLIGHT_PARAMETER_TABLE_H_
#define _FLIGHT_PARAMETER_TABLE_H_

#include "stm32f4xx.h"                  // Device header


//stm32f103c8    FLASH��0x0800FFFF��ֹ��64K��
//stm32f103cB    FLASH��0x0801FFFF��ֹ��128K��
//FLASH ��������ʼ��ַ
#define ADDR_FLASH_SECTOR_0     ((u32)0x08000000) 	//����0��ʼ��ַ, 16 Kbytes  
#define ADDR_FLASH_SECTOR_1     ((u32)0x08004000) 	//����1��ʼ��ַ, 16 Kbytes  
#define ADDR_FLASH_SECTOR_2     ((u32)0x08008000) 	//����2��ʼ��ַ, 16 Kbytes  
#define ADDR_FLASH_SECTOR_3     ((u32)0x0800C000) 	//����3��ʼ��ַ, 16 Kbytes  
#define ADDR_FLASH_SECTOR_4     ((u32)0x08010000) 	//����4��ʼ��ַ, 64 Kbytes  
#define ADDR_FLASH_SECTOR_5     ((u32)0x08020000) 	//����5��ʼ��ַ, 128 Kbytes  
#define ADDR_FLASH_SECTOR_6     ((u32)0x08040000) 	//����6��ʼ��ַ, 128 Kbytes  
#define ADDR_FLASH_SECTOR_7     ((u32)0x08060000) 	//����7��ʼ��ַ, 128 Kbytes  
#define ADDR_FLASH_SECTOR_8     ((u32)0x08080000) 	//����8��ʼ��ַ, 128 Kbytes  
#define ADDR_FLASH_SECTOR_9     ((u32)0x080A0000) 	//����9��ʼ��ַ, 128 Kbytes  
#define ADDR_FLASH_SECTOR_10    ((u32)0x080C0000) 	//����10��ʼ��ַ,128 Kbytes  
#define ADDR_FLASH_SECTOR_11    ((u32)0x080E0000) 	//����11��ʼ��ַ,128 Kbytes  


#define PARAMETER_TABLE_STARTADDR   ADDR_FLASH_SECTOR_11 //0x0801FA00+190(0x(100*4))
#define FLIGHT_PARAMETER_TABLE_NUM  150

typedef struct
{
   float Parameter_Table[FLIGHT_PARAMETER_TABLE_NUM];
}FLIGHT_PARAMETER;



typedef enum
{
	PITCH_OFFSET = 0,
	ROLL_OFFSET = 1,
	ACCEL_X_OFFSET = 2,
	ACCEL_Y_OFFSET = 3,
	ACCEL_Z_OFFSET = 4,
	ACCEL_X_SCALE = 5,
	ACCEL_Y_SCALE = 6,
	ACCEL_Z_SCALE = 7,
	MAG_X_OFFSET = 8,
	MAG_Y_OFFSET = 9,
	MAG_Z_OFFSET = 10,
	RC_CH1_MAX = 11,
	RC_CH1_MIN = 12,
	RC_CH2_MAX = 13,
	RC_CH2_MIN = 14,
	RC_CH3_MAX = 15,
	RC_CH3_MIN = 16,
	RC_CH4_MAX = 17,
	RC_CH4_MIN = 18,
	RC_CH5_MAX = 19,
	RC_CH5_MIN = 20,
	RC_CH6_MAX = 21,
	RC_CH6_MIN = 22,
	RC_CH7_MAX = 23,
	RC_CH7_MIN = 24,
	RC_CH8_MAX = 25,
	RC_CH8_MIN = 26,
	PID1_PARAMETER_KP = 27,
	PID1_PARAMETER_KI = 28,
	PID1_PARAMETER_KD = 29,
	PID2_PARAMETER_KP = 30,
	PID2_PARAMETER_KI = 31,
	PID2_PARAMETER_KD = 32,
	PID3_PARAMETER_KP = 33,
	PID3_PARAMETER_KI = 34,
	PID3_PARAMETER_KD = 35,
	PID4_PARAMETER_KP = 36,
	PID4_PARAMETER_KI = 37,
	PID4_PARAMETER_KD = 38,
	PID5_PARAMETER_KP = 39,
	PID5_PARAMETER_KI = 40,
	PID5_PARAMETER_KD = 41,
	PID6_PARAMETER_KP = 42,
	PID6_PARAMETER_KI = 43,
	PID6_PARAMETER_KD = 44,
	PID7_PARAMETER_KP = 45,
	PID7_PARAMETER_KI = 46,
	PID7_PARAMETER_KD = 47,
	PID8_PARAMETER_KP = 48,
	PID8_PARAMETER_KI = 49,
	PID8_PARAMETER_KD = 50,
	PID9_PARAMETER_KP = 51,
	PID9_PARAMETER_KI = 52,
	PID9_PARAMETER_KD = 53,
	PID10_PARAMETER_KP = 54,
	PID10_PARAMETER_KI = 55,
	PID10_PARAMETER_KD = 56,
	PID11_PARAMETER_KP = 57,
	PID11_PARAMETER_KI = 58,
	PID11_PARAMETER_KD = 59,
	PID12_PARAMETER_KP = 60,
	PID12_PARAMETER_KI = 61,
	PID12_PARAMETER_KD = 62,
	PID13_PARAMETER_KP = 63,
	PID13_PARAMETER_KI = 64,
	PID13_PARAMETER_KD = 65,
	PID14_PARAMETER_KP = 66,
	PID14_PARAMETER_KI = 67,
	PID14_PARAMETER_KD = 68,
	PID15_PARAMETER_KP = 69,
	PID15_PARAMETER_KI = 70,
	PID15_PARAMETER_KD = 71,
	PID16_PARAMETER_KP = 72,
	PID16_PARAMETER_KI = 73,
	PID16_PARAMETER_KD = 74,
	PID17_PARAMETER_KP = 75,
	PID17_PARAMETER_KI = 76,
	PID17_PARAMETER_KD = 77,
	PID18_PARAMETER_KP = 78,
	PID18_PARAMETER_KI = 79,
	PID18_PARAMETER_KD = 80,
	PID19_PARAMETER_KP = 81,
	PID19_PARAMETER_KI = 82,
	PID19_PARAMETER_KD = 83,
	ESC_CALIBRATION_FLAG = 84,
	DATA_TRUE_FLAG = 85,
	HOR_CAL_ACCEL_X = 86,
	HOR_CAL_ACCEL_Y = 87,
	HOR_CAL_ACCEL_Z = 88,
	SDK_MODE_DEFAULT = 89,
	LEFT_1 = 90,
	AHEAD_1 = 91,
	LEFT_2 = 92,
	AHEAD_2 = 93,
	RIGHT_1 = 94,
	BACK_1 = 95,
	RIGHT_2 = 96,
	AHEAD_3 = 97,
	RIGHT_3 = 98,
	BACK_2 = 99,
	RIGHT_4 = 100,
	AHEAD_4 = 101,
	flyhight = 102,
	FLY_speed = 103,
	colour1 = 104,
	colour2 = 105,
	colour3 = 106,
	colour4 = 107,
	Danger_Place = 108,
	Read_Number = 109,
	Third_Number = 113,
	Del_Stage = 110,
	First_Number = 111,
	Second_Number = 112,
	tsk_hight = 114,
}FLIGHT_PARAMETER_TABLE;




void ReadFlashParameterALL(FLIGHT_PARAMETER *WriteData);
uint8_t ReadFlashParameterOne(uint16_t Label,float *ReadData);
uint8_t ReadFlashParameterTwo(uint16_t Label,float *ReadData1,float *ReadData2);
uint8_t ReadFlashParameterThree(uint16_t Label,float *ReadData1,float *ReadData2,float *ReadData3);
   
   
void WriteFlashParameter(uint16_t Label,float WriteData,FLIGHT_PARAMETER *Table);
void WriteFlashParameter_Two(uint16_t Label,
                         float WriteData1,
                         float WriteData2,
                         FLIGHT_PARAMETER *Table);
void WriteFlashParameter_Three(uint16_t Label,
                         float WriteData1,
                         float WriteData2,
                         float WriteData3,
                         FLIGHT_PARAMETER *Table);
uint8_t ReadFlashParameterTwo(uint16_t Label,float *ReadData1,float *ReadData2);
void WriteFlashParameter_TOADDR_FLASH_SECTOR(FLIGHT_PARAMETER *Table);
extern FLIGHT_PARAMETER Table_Parameter;
extern volatile FLASH_Status Parameter_Table_FLASHStatus;      //Flash����״̬����
uint16_t STMFLASH_GetFlashSector(uint32_t addr);

#endif

