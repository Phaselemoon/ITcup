#include "stm32f4xx.h"                  // Device header
#include "sys.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "pwm.h"
#include "serial.h"
#include "timer.h"
#include "exti.h"
#include "adc.h"
#include "EMM.h"
// #include "lcd.h"
#include "oled_spi.h"
#include "ADC.h"
#include "Kinematics.h"
#include "Control.h"
#include "Menu.h"
#include "Gray.h"
#include "Buzzer.h"
#include "Motor.h"
#include "Menu.h"

//char String1[100];
//sprintf(String1,);
//Serial_SendString1(String1);


uint32_t speedl,speedr = 0;


int main(void)
{ 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);  														//��ʼ����ʱ����
	
  	LED_Init();  
	Buzzer_Init();
	//Adc_Init();    																//adc��ʼ��
	//MyCan_Init();
	KEY_Init();	
	//motor_init();
	//LCD_Init();
	OLED_Init();
	
	//Load_saved_sdk_parament();
	
	//Usart1_Init(115200);		
										//	Usart2_Init(115200);		
										//	Usart3_Init(115200);		
										//	UART4_Init(115200);			
										//	UART5_Init(115200);
											
										//	TIM5_Int_Init(1000-1,840-1);									//��ʱ��3��ʼ�� 20msһ��
	// delay_ms(1000);
	// Emm_V5_Pos_Control(1,0,500,0,5000,0,0);
	// delay_ms(50);
	// Emm_V5_Pos_Control(2,0,500,0,5000,0,0);
	// delay_ms(50);
	while(1) 
	{
		//Serial_SendByte1(0xAA);
		//delay_ms(100);
		//Motor_Control_Foward(50, 150);
		//DMA_USART1_Data_Prase();
										//		DMA_USART2_Data_Prase();
										//		DMA_USART3_Data_Prase();
										//		DMA_USART4_Data_Prase();
										//		DMA_USART5_Data_Prase();

										//		UART4_Tx_HWT();
		


		Key_Scan();
		Menu_Table();


		OLED_ShowString(0,0,"TEST1",12);
		OLED_ShowString(0,12,"TEST2",12);
		OLED_ShowString(0,24,"TEST3",12);
		OLED_ShowString(0,36,"TEST4",12);
		OLED_ShowString(0,48,"TEST5",12);


		OLED_ShowString(36,0,"TEST2",12);
		OLED_ShowString(72,0,"TEST3",12);
		OLED_Fill(36,12,72,24,1);
		// OLED_ShowString(3,1,"TEST",16);
		// OLED_ShowString(0,0, "TE",12);  
		// OLED_ShowString(0,50,"SAVING",12);
		OLED_Refresh_Gram();//������ʾ��OLED	 


	}
}


