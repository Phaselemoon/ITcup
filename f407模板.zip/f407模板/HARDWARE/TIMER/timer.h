#ifndef _TIMER_H
#define _TIMER_H

#include "stm32f4xx.h"                  // Device header
#include "sys.h"
#include "EMM.h"
#include "MyCan.h"
#include "Serial.h"
#include "Kinematics.h"

#define Timer_TIM TIM5

void TIM5_Int_Init(uint16_t arr,uint16_t psc);

//������̼����ݰ�


extern int64_t motor_rpm[2];
extern uint32_t n;



#endif
