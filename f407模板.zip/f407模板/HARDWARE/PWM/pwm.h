#ifndef _PWM_H
#define _PWM_H

#include "stm32f4xx.h"                  // Device header
#include "sys.h"


#define PWM_TWO_WHEEL  1
#define PWM_FOUR_WHEEL 0
#define PWM_DATA_C PWM_TWO_WHEEL
#define PWM_DATA_H PWM_TWO_WHEEL

#if PWM_DATA_H == PWM_TWO_WHEEL

#define PWM_TIMER  TIM2
#define RCC_TIMER  RCC_APB1Periph_TIM2
#define RCC_TIMER_IO RCC_AHB1Periph_GPIOA
#define PWM_TIMER_PORT_L GPIOA
#define PWM_TIMER_PORT_R GPIOA
#define PWM_TIMER_L_SOURCE GPIO_PinSource0
#define PWM_TIMER_R_SOURCE GPIO_PinSource1
#define PWM_TIMER_Pin_L GPIO_Pin_0
#define PWM_TIMER_Pin_R GPIO_Pin_1

#define PWM_TIMER_AF_L GPIO_AF_TIM2
#define PWM_TIMER_AF_R GPIO_AF_TIM2

void motor_set_compare( uint16_t Compare0,uint16_t Compare1);//���Ƶ��

#endif

#if PWM_DATA_H == PWM_FOUR_WHEEL

#define PWM_TIMER  TIM2
#define RCC_TIMER  RCC_APB1Periph_TIM2
#define RCC_TIMER_IO RCC_AHB1Periph_GPIOB
#define PWM_TIMER_PORT_LF GPIOB
#define PWM_TIMER_PORT_RF GPIOB
#define PWM_TIMER_PORT_LB GPIOB
#define PWM_TIMER_PORT_RB GPIOB

#define PWM_TIMER_Pin_LF GPIO_Pin_4 
#define PWM_TIMER_Pin_RF GPIO_Pin_4
#define PWM_TIMER_Pin_LB GPIO_Pin_4
#define PWM_TIMER_Pin_RB GPIO_Pin_4


#endif




void PWM_Init(uint32_t arr,uint32_t psc);

#endif
