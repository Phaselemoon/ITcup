//#ifndef __VOFA_USART_H
//#define __VOFA_USART_H

//#include "stm32f4xx.h"                  // Device header
//#include <stdarg.h>
//#include <stdio.h>

//void VOFA_Usart_Init(uint32_t bound);
//void VOFA_Send_Byte(uint8_t Byte);
//void VOFA_Send_Array(uint8_t *Array,uint16_t Length);
//void VOFA_Send_String(char*String);
//void VOFA_Send_Number(uint32_t Num,uint8_t Length);
//void VOFA_Usart_Printf(char *format,...);
//uint8_t VOFA_Usart_GetRxFlag(void);
//uint8_t VOFA_Usart_GetRxData(void);

//uint8_t Get_id_Flag(void);//����ȡid_Flag��װ�ɺ���
//float RxPacket_Data_Handle(void);//���ݰ����㴦��

//void Float_to_Byte(float Fdata,uint8_t *ArrayByte);
//void FasongFloat(float a,float b,float c,float d);

//#endif
