//#ifndef __EXTI_H
//#define __EXIT_H	 

//#include "stm32f4xx.h"                  // Device header
//#include "sys.h"  	

//#include "delay.h" 
//#include "led.h" 
//#include "key.h"


//#define down		  0
//#define up			  1
//#define enter   	2
//#define back     	3

//extern uint16_t Key_Num;
//void EXTIX_Init(void);	//�ⲿ�жϳ�ʼ��		


//#endif

























