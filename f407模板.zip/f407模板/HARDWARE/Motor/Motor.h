#ifndef __Motor_H
#define __Motor_H

void motor_init(void);


#define New_TB6612  0
#define TB6612 			1
#define Motor_Control_Define New_TB6612

#define Control_TWO_WHEEL 0
#define Control_FOUR_WHEEL 1
//#define Control_DATA_C Control_TWO_WHEEL
#define Control_DATA_H Control_TWO_WHEEL

#if Motor_Control_Define == New_TB6612
	#if Control_DATA_H == Control_TWO_WHEEL

	#define RCC_CONTORL_L 		RCC_AHB1Periph_GPIOE
	#define RCC_CONTROL_R 		RCC_AHB1Periph_GPIOE
	#define RCC_CONTROL_Stop 	RCC_AHB1Periph_GPIOE
	
	#define CONTROL_PORT_L 		GPIOE
	#define CONTROL_PORT_R	 	GPIOE
	#define CONTROL_PORT_STOP GPIOE
	
	#define CONTROL_Pin_L 		GPIO_Pin_4
	#define CONTROL_Pin_R 		GPIO_Pin_5
	#define CONTROL_Pin_STOP 	GPIO_Pin_6

	#define 	AIN1_HIGH		GPIO_WriteBit(CONTROL_PORT_L, CONTROL_Pin_L, Bit_SET)
	#define 	AIN1_LOW		GPIO_WriteBit(CONTROL_PORT_L, CONTROL_Pin_L, Bit_RESET)

	#define 	AIN2_HIGH		GPIO_WriteBit(CONTROL_PORT_R, CONTROL_Pin_R, Bit_SET)
	#define 	AIN2_LOW		GPIO_WriteBit(CONTROL_PORT_R, CONTROL_Pin_R, Bit_RESET)

	#define   STOP_HIGH		GPIO_WriteBit(CONTROL_PORT_STOP, CONTROL_Pin_STOP, Bit_SET)
	#define		STOP_LOW		GPIO_WriteBit(CONTROL_PORT_STOP, CONTROL_Pin_STOP, Bit_RESET)
	
	void Motor_Control_Foward(int Speed1, int Speed2);
	void Motor_Control_Backward(int Speed1, int Speed2);
	void Motor_Control_Right(int Speed1, int Speed2);
	void Motor_Control_Left(int Speed1, int Speed2);
	void Motor_Stop(void);
	
	#endif

	#if Control_DATA_H == Control_FOUR_WHEEL
	
	#endif
#endif

#if Motor_Control_Define == TB6612
	#if Control_DATA_H == Control_TWO_WHEEL

	#define 	AIN1_HIGH		GPIO_WriteBit(GPIOC, GPIO_Pin_7, Bit_SET)
	#define 	AIN1_LOW		GPIO_WriteBit(GPIOC, GPIO_Pin_7, Bit_RESET)

	#define 	AIN2_HIGH		GPIO_WriteBit(GPIOC, GPIO_Pin_6, Bit_SET)
	#define 	AIN2_LOW		GPIO_WriteBit(GPIOC, GPIO_Pin_6, Bit_RESET)

	#define   STOP_HIGH		GPIO_WriteBit(GPIOC, GPIO_Pin_12, Bit_SET)
	#define		STOP_LOW		GPIO_WriteBit(GPIOC, GPIO_Pin_12, Bit_RESET)
	#endif

	#if Control_DATA_H == Control_FOUR_WHEEL
	
	#endif
#endif


#endif
