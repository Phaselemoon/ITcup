#include "stm32f4xx.h"                  // Device header
#include "pwm.h"
#include "Motor.h"


#if Motor_Control_Define == New_TB6612
void motor_init(void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_CONTORL_L, ENABLE);//ʹ��GPIOAʱ��
//	RCC_AHB1PeriphClockCmd(RCC_CONTORL_R, ENABLE);//ʹ��GPIOAʱ��
//	RCC_AHB1PeriphClockCmd(RCC_CONTORL_STOP, ENABLE);//ʹ��GPIOAʱ��
	
	//GPIOF9,F10��ʼ������
	GPIO_InitStructure.GPIO_Pin = CONTROL_Pin_L|CONTROL_Pin_R|CONTROL_Pin_STOP;//LED2��ӦIO��
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
	GPIO_Init(CONTROL_PORT_L, &GPIO_InitStructure);//��ʼ��GPIO
	GPIO_Init(CONTROL_PORT_R, &GPIO_InitStructure);//��ʼ��GPIO
	GPIO_Init(CONTROL_PORT_STOP, &GPIO_InitStructure);//��ʼ��GPIO
	
	PWM_Init(500-1,84-1);

}

void Motor_Control_Foward(int Speed1, int Speed2)//
{
	AIN1_HIGH;
	AIN2_LOW;
	STOP_HIGH;

	if(Speed1<0)
	{
		Speed1=-Speed1;
	}
	if(Speed2<0)
	{
		Speed2=-Speed2;
	}
	
	motor_set_compare( Speed1,Speed2 );
}
void Motor_Control_Backward(int Speed1, int Speed2)
{
	AIN1_LOW;
	AIN2_HIGH;
	STOP_HIGH;

	if(Speed1<0)
	{
		Speed1=-Speed1;
	}
	if(Speed2<0)
	{
		Speed2=-Speed2;
	}
	
	motor_set_compare( Speed1,Speed2 );
}
void Motor_Control_Right(int Speed1, int Speed2)
{
	AIN1_LOW;
	AIN2_LOW;
	STOP_HIGH;

	if(Speed1<0)
	{
		Speed1=-Speed1;
	}
	if(Speed2<0)
	{
		Speed2=-Speed2;
	}
	
	motor_set_compare( Speed1,Speed2 );
}
void Motor_Control_Left(int Speed1, int Speed2)
{
	AIN1_HIGH;
	AIN2_HIGH;
	STOP_HIGH;

	if(Speed1<0)
	{
		Speed1=-Speed1;
	}
	if(Speed2<0)
	{
		Speed2=-Speed2;
	}
	
	motor_set_compare( Speed1,Speed2 );
}

void Motor_Stop(void)
{
	STOP_LOW;
	
	motor_set_compare( 0,0 );
}
#endif

#if Motor_Control_Define == TB6612
void motor_init(void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);//ʹ��GPIOAʱ��

	//GPIOF9,F10��ʼ������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7|GPIO_Pin_6|GPIO_Pin_12;//LED2��ӦIO��
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
	GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��GPIO
	
	PWM_Init(500-1,84-1);

}

void Motor_Control_Foward(int Speed1, int Speed2)//
{
	AIN1_HIGH;
	AIN2_LOW;
	STOP_HIGH;

	if(Speed1<0)
	{
		Speed1=-Speed1;
	}
	if(Speed2<0)
	{
		Speed2=-Speed2;
	}
	
	motor_set_compare( Speed1,Speed2 );
}
void Motor_Control_Backward(int Speed1, int Speed2)
{
	AIN1_LOW;
	AIN2_HIGH;
	STOP_HIGH;

	if(Speed1<0)
	{
		Speed1=-Speed1;
	}
	if(Speed2<0)
	{
		Speed2=-Speed2;
	}
	
	motor_set_compare( Speed1,Speed2 );
}
void Motor_Control_Right(int Speed1, int Speed2)
{
	AIN1_LOW;
	AIN2_LOW;
	STOP_HIGH;

	if(Speed1<0)
	{
		Speed1=-Speed1;
	}
	if(Speed2<0)
	{
		Speed2=-Speed2;
	}
	
	motor_set_compare( Speed1,Speed2 );
}
void Motor_Control_Left(int Speed1, int Speed2)
{
	AIN1_HIGH;
	AIN2_HIGH;
	STOP_HIGH;

	if(Speed1<0)
	{
		Speed1=-Speed1;
	}
	if(Speed2<0)
	{
		Speed2=-Speed2;
	}
	
	motor_set_compare( Speed1,Speed2 );
}

void Motor_Stop(void)
{
	STOP_LOW;
	
	motor_set_compare( 0,0 );
}
#endif









