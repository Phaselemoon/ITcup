#ifndef _CONTROL_H
#define _CONTROL_H

#include "stm32f4xx.h"                  // Device header
#include <math.h>
#include "stdio.h"
#include "stdbool.h"
#include "Serial.h"
#include "EMM.h"
#include "delay.h"
#include "pid.h"
#include "MyCan.h"
#include "kinematics.h"
#include "timer.h"

#define Body_Radius 0.08 //��λ;M
#define Wheel_diameter 0.065 //��λ��M


#define  Go_to_center   	 				1     
#define  Go_to_safe   						2    
#define  Seek_Aim    							3    
#define  fang_qiu				   				4    
#define  Stop											5
#define  Seek_Aim_Success					6
#define  Remote_Control						7
#define	 Seek_Aim_NO							8
#define  check_aim                9



extern uint8_t State ;
extern uint8_t Last_State;
extern uint8_t arrive_flag;


extern uint8_t ball_bian;

void controlcar_Init(void);
void Set_Angle(float set_angle);
void Seek_Aim_EMM(void);
void Seek_Dir_EMM(float setAngle);
void Control_Car(void);

#endif
