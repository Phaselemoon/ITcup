#ifndef __Buzzer_H
#define __Buzzer_H

void Buzzer_Init(void);
void Buzzer_Turn(void);
void Buzzer_ON(void);
void Buzzer_OFF(void);

#define	Buzzer_GPIO				GPIOE
#define Buzzer_GPIO_Pin			GPIO_Pin_1

#endif
