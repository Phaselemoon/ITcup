#include "stm32f4xx.h"                  // Device header

#include "Buzzer.h"

void Buzzer_Init(void)
{
 GPIO_InitTypeDef GPIO_InitStructure;

    // ����GPIOEʱ��
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);

    // ����PE15Ϊ�������ģʽ���ٶ�Ϊ50MHz
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    // Ĭ�Ϲرշ�����
    Buzzer_OFF();
}

void Buzzer_ON(void)
{	
	GPIO_SetBits(GPIOE,GPIO_Pin_1);	

}	


void Buzzer_OFF(void)
{
	GPIO_ResetBits(GPIOE,GPIO_Pin_1);
}