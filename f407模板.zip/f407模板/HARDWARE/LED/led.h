#ifndef __LED_H
#define __LED_H

#include "sys.h"

typedef enum{LED1 = 0, LED2 = 1, LED3 = 2, LED_ALL = 3}eLEDnum;
typedef enum{OFF = 0, ON = 1}eLEDstate;

#define   LED1_Port GPIOE
#define   LED2_Port GPIOE
#define   LED3_Port GPIOE
#define		LED4_Port GPIOE
					 
#define   LED1_Pin GPIO_Pin_14
#define   LED2_Pin GPIO_Pin_15
#define   LED3_Pin GPIO_Pin_13
#define 	LED4_Pin GPIO_Pin_12

#define LED1_ON 		GPIO_WriteBit(LED1_Port,LED1_Pin, Bit_RESET)
#define LED1_OFF 		GPIO_WriteBit(LED1_Port,LED1_Pin, Bit_SET)

#define LED2_ON 		GPIO_WriteBit(LED2_Port,LED2_Pin, Bit_RESET)
#define LED2_OFF 		GPIO_WriteBit(LED2_Port,LED2_Pin, Bit_SET)

#define LED3_ON 		GPIO_WriteBit(LED3_Port,LED3_Pin, Bit_RESET)
#define LED3_OFF 		GPIO_WriteBit(LED3_Port,LED3_Pin, Bit_SET)

#define LED4_ON 		GPIO_WriteBit(LED4_Port,LED4_Pin, Bit_RESET)
#define LED4_OFF 		GPIO_WriteBit(LED4_Port,LED4_Pin, Bit_SET)


void LED_Init(void);//��ʼ��		 	
void LED_SET(unsigned char Pin,unsigned char state);
#endif
