#ifndef __SERIAL_H
#define __SERIAL_H

#include "stm32f4xx.h"                  // Device header

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "Serial.h"
#include "delay.h"
#include "SBUS.h"
#include "sys.h"

#define DMA_USART1_DMA_Stream   DMA2_Stream5 
#define DMA_USART1				USART1
#define DMA_USART1_GPIO_AF		GPIO_AF_USART1
#define DMA_USART1_IO_CLOCK		RCC_AHB1Periph_GPIOA
#define DMA_USART1_CLOCK		RCC_APB2Periph_USART1
#define DMA_USART1_IO_PORT		GPIOA
#define DMA_USART1_TX			GPIO_Pin_9
#define DMA_USART1_RX			GPIO_Pin_10
#define DMA_USART1_TX_PinSource  GPIO_PinSource9
#define DMA_USART1_RX_PinSource  GPIO_PinSource10

#define DMA_USART2_DMA_Stream   DMA1_Stream5 
#define DMA_USART2				USART2
#define DMA_USART2_GPIO_AF		GPIO_AF_USART2
#define DMA_USART2_IO_CLOCK		RCC_AHB1Periph_GPIOD
#define DMA_USART2_CLOCK		RCC_APB1Periph_USART2
#define DMA_USART2_IO_PORT		GPIOD
#define DMA_USART2_TX			GPIO_Pin_5
#define DMA_USART2_RX			GPIO_Pin_6
#define DMA_USART2_TX_PinSource  GPIO_PinSource5
#define DMA_USART2_RX_PinSource  GPIO_PinSource6

#define DMA_USART3_DMA_Stream   DMA1_Stream1
#define DMA_USART3				USART3
#define DMA_USART3_GPIO_AF		GPIO_AF_USART3
#define DMA_USART3_IO_CLOCK		RCC_AHB1Periph_GPIOD
#define DMA_USART3_CLOCK		RCC_APB1Periph_USART3
#define DMA_USART3_IO_PORT		GPIOD
#define DMA_USART3_TX			GPIO_Pin_8
#define DMA_USART3_RX			GPIO_Pin_9
#define DMA_USART3_TX_PinSource  GPIO_PinSource8
#define DMA_USART3_RX_PinSource  GPIO_PinSource9

#define DMA_USART4_DMA_Stream   DMA1_Stream2
#define DMA_USART4				UART4
#define DMA_USART4_GPIO_AF		GPIO_AF_UART4
#define DMA_USART4_IO_CLOCK		RCC_AHB1Periph_GPIOC
#define DMA_USART4_CLOCK		RCC_APB1Periph_UART4
#define DMA_USART4_IO_PORT		GPIOC
#define DMA_USART4_TX			GPIO_Pin_10
#define DMA_USART4_RX			GPIO_Pin_11
#define DMA_USART4_TX_PinSource  GPIO_PinSource10
#define DMA_USART4_RX_PinSource  GPIO_PinSource11

#define DMA_USART5_DMA_Stream   DMA1_Stream0
#define DMA_USART5				UART5
#define DMA_USART5_GPIO_AF		GPIO_AF_UART5
#define DMA_USART5_IO_RX_CLOCK		RCC_AHB1Periph_GPIOC
#define DMA_USART5_IO_TX_CLOCK		RCC_AHB1Periph_GPIOD
#define DMA_USART5_CLOCK		RCC_APB1Periph_UART5
#define DMA_USART5_IO_RX_PORT		GPIOC
#define DMA_USART5_IO_TX_PORT		GPIOD
#define DMA_USART5_TX			GPIO_Pin_12
#define DMA_USART5_RX			GPIO_Pin_2
#define DMA_USART5_TX_PinSource  GPIO_PinSource12
#define DMA_USART5_RX_PinSource  GPIO_PinSource2


extern uint8_t DMA_USART1_RxBuffer[300];
extern int DMA_USART1_Length;

extern uint8_t DMA_USART2_RxBuffer[300];
extern int DMA_USART2_Length;

extern uint8_t DMA_USART3_RxBuffer[300];
extern int DMA_USART3_Length;

extern uint8_t DMA_USART4_RxBuffer[300];
extern int DMA_USART4_Length;

extern uint8_t DMA_USART5_RxBuffer[300];
extern int DMA_USART5_Length;


typedef struct
{
	int X;
	int Y;
}ladar_Map;

extern ladar_Map ladar_map;

#define Data_num    6  //�����Ӹ�����һ

#define HEADER_0 0xA5
#define HEADER_1 0x5A
#define Length_  0x6C
#define POINT_PER_PACK	32

/***����������***/

/****ң����ʹ����****/
extern uint8_t Remote_Flag;								//ң����ʹ�ñ�־

/****����ͷʹ����****/
extern uint8_t  Ball_X,Ball_Y,Ball_Distence,State_Change;//����ͷ�ش�����
extern uint8_t check_num;

void Usart3_Tx_Cameral(uint8_t a,uint8_t b,uint8_t c,uint8_t d);

/****������ʹ��ȥ��****/
extern uint16_t Angle_Usart;
extern uint16_t Y_Vel;
extern uint16_t Z_Vel;
extern volatile uint8_t Data_MPU_Flag;
extern float angle;
void Data_MPU_Process(void);

void DMA_USART1_Data_Prase(void);
void DMA_USART2_Data_Prase(void);
void DMA_USART3_Data_Prase(void);
void DMA_USART4_Data_Prase(void);
void DMA_USART5_Data_Prase(void);

extern int ladar_x_data;
extern int ladar_y_data;
extern int ladar_z_data;


float float_abs(float input);

/****��ʼ������****/
void Usart1_Init(u32 bound);
void Usart2_Init(uint32_t bound);		//�״�
void Usart3_Init(uint32_t bound);		//����ͷ
void UART4_Init(u32 bound);				//������
void UART5_Init(u32 bound);
/****���ͺ���****/
void Serial_SendByte1(uint8_t Byte);
void Serial_SendArray1(uint8_t *Array, uint16_t Length);
void Serial_SendString1(char *String);
void Serial_SendNumber1(uint32_t Number, uint8_t Length);

uint32_t Serial_Pow2(uint32_t X, uint32_t Y);
void Serial_SendByte2(uint8_t Byte);
void Serial_SendArray2(uint8_t *Array, uint16_t Length);
void Serial_SendString2(char *String);
void Serial_SendNumber2(uint32_t Number, uint8_t Length);
int fputc2(int ch, FILE *f);


void Serial_SendByte3(uint8_t Byte);
void Serial_SendArray3(uint8_t *Array, uint16_t Length);
void Serial_SendString3(char *String);
void Serial_SendNumber3(uint32_t Number, uint8_t Length);
void Serial_SendArray3(uint8_t *Array, uint16_t Length);
void Serial_Printf3(char *format, ...);
int fputc2(int ch, FILE *f);

void Serial_SendByte3(uint8_t Byte);

void UART4_Tx_HWT(void);

#endif
