#include "Serial.h"
#include "stm32f4xx.h"                  // Device header

uint8_t DMA_USART1_RxBuffer[300];
int DMA_USART1_Length;

uint8_t DMA_USART2_RxBuffer[300];
int DMA_USART2_Length;

uint8_t DMA_USART3_RxBuffer[300];
int DMA_USART3_Length;

uint8_t DMA_USART4_RxBuffer[300];
int DMA_USART4_Length;

uint8_t DMA_USART5_RxBuffer[300];
int DMA_USART5_Length;

void Usart1_Init(u32 bound)
{ 
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;//定义NVIC初始化结构体
	DMA_InitTypeDef  DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(DMA_USART1_IO_CLOCK, ENABLE);
	RCC_APB2PeriphClockCmd(DMA_USART1_CLOCK, ENABLE);

	GPIO_PinAFConfig(DMA_USART1_IO_PORT, DMA_USART1_TX_PinSource, DMA_USART1_GPIO_AF);
	GPIO_PinAFConfig(DMA_USART1_IO_PORT, DMA_USART1_RX_PinSource, DMA_USART1_GPIO_AF);

	GPIO_InitStructure.GPIO_Pin = DMA_USART1_TX | DMA_USART1_RX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//速度50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //上拉
	GPIO_Init(DMA_USART1_IO_PORT, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;//波特率设置
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//收发模式
	USART_Init(DMA_USART1, &USART_InitStructure); //初始化串口

	USART_ClearFlag(DMA_USART1, USART_FLAG_TC);//清除中断标志位
	USART_ITConfig(DMA_USART1, USART_IT_IDLE, ENABLE);//开启空闲中断，串口接收数据用到了空闲中断，因此必须开启！

	USART_DMACmd(DMA_USART1, USART_DMAReq_Rx, ENABLE);  //使能串口1的DMA接收,这两句与DMA传输相关，一定要使能！！！！！！！！！！！
	USART_DMACmd(DMA_USART1, USART_DMAReq_Tx, ENABLE);  //使能串口1的DMA发送，这两句与DMA传输相关，一定要使能！！！！！！！！！！！

		NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;       //串口1中断通道
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0; //抢占优先级2
    NVIC_InitStructure.NVIC_IRQChannelSubPriority =0;	    //子优先级1
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ通道使能
    NVIC_Init(&NVIC_InitStructure);							//根据指定的参数初始化VIC寄存器、

	//DMAx的各通道配置,外设到存储器
	//这里的传输形式是固定的,这点要根据不同的情况来修改
	//从存储器->外设模式/8位数据宽度/存储器增量模式
	//DMA_Streamx:DMA数据流,DMA1_Stream0~7/DMA2_Stream0~7
	//chx:DMA通道选择,@ref DMA_channel DMA_Channel_0~DMA_Channel_7
	//par:外设地址
	//mar:存储器地址
	//ndtr:数据传输量  


	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);//DMA1时钟使能 
	/* 配置 DMA Stream */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4;  //通道选择
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(DMA_USART1->DR));//DMA外设地址
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)DMA_USART1_RxBuffer;//DMA 存储器0地址
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;//外设模式到存储器！！！，这个配置很关键
	DMA_InitStructure.DMA_BufferSize = 256;//数据传输量 
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//外设非增量模式
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//存储器增量模式
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设数据长度:8位
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//存储器数据长度:8位
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;// 使用普通模式,不循环
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;//中等优先级
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//存储器突发单次传输
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//外设突发单次传输
	//DMA1的数据流1
	DMA_Init(DMA_USART1_DMA_Stream, &DMA_InitStructure);//初始化DMA Stream
	DMA_Cmd(DMA_USART1_DMA_Stream, ENABLE);             //开启DMA传输,只是与前面配置不同的，注意！


	USART_Cmd(DMA_USART1, ENABLE);                    //使能串口
		

}

/**
  * 函    数：串口2初始化
  * 参    数：bound：波特率
  * 返 回 值：无
  */
void Usart2_Init(u32 bound)//串口2初始化 
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;//定义NVIC初始化结构体
	DMA_InitTypeDef  DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(DMA_USART2_IO_CLOCK, ENABLE);
	RCC_APB1PeriphClockCmd(DMA_USART2_CLOCK, ENABLE);

	GPIO_PinAFConfig(DMA_USART2_IO_PORT, DMA_USART2_TX_PinSource, DMA_USART2_GPIO_AF);
	GPIO_PinAFConfig(DMA_USART2_IO_PORT, DMA_USART2_RX_PinSource, DMA_USART2_GPIO_AF);

	GPIO_InitStructure.GPIO_Pin = DMA_USART2_TX | DMA_USART2_RX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//速度50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //上拉
	GPIO_Init(DMA_USART2_IO_PORT, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;//波特率设置
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//收发模式
	USART_Init(DMA_USART2, &USART_InitStructure); //初始化串口

	USART_ClearFlag(DMA_USART2, USART_FLAG_TC);//清除中断标志位
	USART_ITConfig(DMA_USART2, USART_IT_IDLE, ENABLE);//开启空闲中断，串口接收数据用到了空闲中断，因此必须开启！

	USART_DMACmd(DMA_USART2, USART_DMAReq_Rx, ENABLE);  //使能串口1的DMA接收,这两句与DMA传输相关，一定要使能！！！！！！！！！！！
	USART_DMACmd(DMA_USART2, USART_DMAReq_Tx, ENABLE);  //使能串口1的DMA发送，这两句与DMA传输相关，一定要使能！！！！！！！！！！！

	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;       //串口2中断通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0; //抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority =2;	    //子优先级1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);							//根据指定的参数初始化VIC寄存器、

	//DMAx的各通道配置,外设到存储器
	//这里的传输形式是固定的,这点要根据不同的情况来修改
	//从存储器->外设模式/8位数据宽度/存储器增量模式
	//DMA_Streamx:DMA数据流,DMA1_Stream0~7/DMA2_Stream0~7
	//chx:DMA通道选择,@ref DMA_channel DMA_Channel_0~DMA_Channel_7
	//par:外设地址
	//mar:存储器地址
	//ndtr:数据传输量  


	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);//DMA1时钟使能 
	/* 配置 DMA Stream */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4;  //通道选择
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(DMA_USART2->DR));//DMA外设地址
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)DMA_USART2_RxBuffer;//DMA 存储器0地址
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;//外设模式到存储器！！！，这个配置很关键
	DMA_InitStructure.DMA_BufferSize = 256;//数据传输量 
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//外设非增量模式
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//存储器增量模式
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设数据长度:8位
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//存储器数据长度:8位
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;// 使用普通模式,不循环
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;//中等优先级
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//存储器突发单次传输
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//外设突发单次传输
	//DMA1的数据流1
	DMA_Init(DMA_USART2_DMA_Stream, &DMA_InitStructure);//初始化DMA Stream
	DMA_Cmd(DMA_USART2_DMA_Stream, ENABLE);             //开启DMA传输,只是与前面配置不同的，注意！


	USART_Cmd(DMA_USART2, ENABLE);                    //使能串口
}    

/**
  * 函    数：串口3初始化
  * 参    数：bound：波特率
  * 返 回 值：无
  */
void Usart3_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;//定义NVIC初始化结构体
	DMA_InitTypeDef  DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(DMA_USART3_IO_CLOCK, ENABLE);
	RCC_APB1PeriphClockCmd(DMA_USART3_CLOCK, ENABLE);

	GPIO_PinAFConfig(DMA_USART3_IO_PORT, DMA_USART3_TX_PinSource, DMA_USART3_GPIO_AF);
	GPIO_PinAFConfig(DMA_USART3_IO_PORT, DMA_USART3_RX_PinSource, DMA_USART3_GPIO_AF);

	GPIO_InitStructure.GPIO_Pin = DMA_USART3_TX | DMA_USART3_RX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//速度50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //上拉
	GPIO_Init(DMA_USART3_IO_PORT, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;//波特率设置
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//收发模式
	USART_Init(DMA_USART3, &USART_InitStructure); //初始化串口

	USART_ClearFlag(DMA_USART3, USART_FLAG_TC);//清除中断标志位
	USART_ITConfig(DMA_USART3, USART_IT_IDLE, ENABLE);//开启空闲中断，串口接收数据用到了空闲中断，因此必须开启！

	USART_DMACmd(DMA_USART3, USART_DMAReq_Rx, ENABLE);  //使能串口1的DMA接收,这两句与DMA传输相关，一定要使能！！！！！！！！！！！
	USART_DMACmd(DMA_USART3, USART_DMAReq_Tx, ENABLE);  //使能串口1的DMA发送，这两句与DMA传输相关，一定要使能！！！！！！！！！！！

	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;       //串口2中断通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0; //抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority =2;	    //子优先级1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);							//根据指定的参数初始化VIC寄存器、
	//DMAx的各通道配置,外设到存储器
	//这里的传输形式是固定的,这点要根据不同的情况来修改
	//从存储器->外设模式/8位数据宽度/存储器增量模式
	//DMA_Streamx:DMA数据流,DMA1_Stream0~7/DMA2_Stream0~7
	//chx:DMA通道选择,@ref DMA_channel DMA_Channel_0~DMA_Channel_7
	//par:外设地址
	//mar:存储器地址
	//ndtr:数据传输量  


	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);//DMA1时钟使能 
	/* 配置 DMA Stream */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4;  //通道选择
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(DMA_USART3->DR));//DMA外设地址
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)DMA_USART3_RxBuffer;//DMA 存储器0地址
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;//外设模式到存储器！！！，这个配置很关键
	DMA_InitStructure.DMA_BufferSize = 256;//数据传输量 
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//外设非增量模式
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//存储器增量模式
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设数据长度:8位
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//存储器数据长度:8位
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;// 使用普通模式,不循环
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;//中等优先级
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//存储器突发单次传输
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//外设突发单次传输
	//DMA1的数据流1
	DMA_Init(DMA_USART3_DMA_Stream, &DMA_InitStructure);//初始化DMA Stream
	DMA_Cmd(DMA_USART3_DMA_Stream, ENABLE);             //开启DMA传输,只是与前面配置不同的，注意！


	USART_Cmd(DMA_USART3, ENABLE);                    //使能串口
}

void UART4_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;//定义NVIC初始化结构体
	DMA_InitTypeDef  DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(DMA_USART4_IO_CLOCK, ENABLE);
	RCC_APB1PeriphClockCmd(DMA_USART4_CLOCK, ENABLE);

	GPIO_PinAFConfig(DMA_USART4_IO_PORT, DMA_USART4_TX_PinSource, DMA_USART4_GPIO_AF);
	GPIO_PinAFConfig(DMA_USART4_IO_PORT, DMA_USART4_RX_PinSource, DMA_USART4_GPIO_AF);

	GPIO_InitStructure.GPIO_Pin = DMA_USART4_TX | DMA_USART4_RX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//速度50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //上拉
	GPIO_Init(DMA_USART4_IO_PORT, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;//波特率设置
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//收发模式
	USART_Init(DMA_USART4, &USART_InitStructure); //初始化串口

	USART_ClearFlag(DMA_USART4, USART_FLAG_TC);//清除中断标志位
	USART_ITConfig(DMA_USART4, USART_IT_IDLE, ENABLE);//开启空闲中断，串口接收数据用到了空闲中断，因此必须开启！

	USART_DMACmd(DMA_USART4, USART_DMAReq_Rx, ENABLE);  //使能串口1的DMA接收,这两句与DMA传输相关，一定要使能！！！！！！！！！！！
	USART_DMACmd(DMA_USART4, USART_DMAReq_Tx, ENABLE);  //使能串口1的DMA发送，这两句与DMA传输相关，一定要使能！！！！！！！！！！！

	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;       //串口2中断通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0; //抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority =2;	    //子优先级1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);							//根据指定的参数初始化VIC寄存器、
	
	//DMAx的各通道配置,外设到存储器
	//这里的传输形式是固定的,这点要根据不同的情况来修改
	//从存储器->外设模式/8位数据宽度/存储器增量模式
	//DMA_Streamx:DMA数据流,DMA1_Stream0~7/DMA2_Stream0~7
	//chx:DMA通道选择,@ref DMA_channel DMA_Channel_0~DMA_Channel_7
	//par:外设地址
	//mar:存储器地址
	//ndtr:数据传输量  


	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);//DMA1时钟使能 
	/* 配置 DMA Stream */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4;  //通道选择
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(DMA_USART4->DR));//DMA外设地址
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)DMA_USART4_RxBuffer;//DMA 存储器0地址
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;//外设模式到存储器！！！，这个配置很关键
	DMA_InitStructure.DMA_BufferSize = 256;//数据传输量 
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//外设非增量模式
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//存储器增量模式
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设数据长度:8位
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//存储器数据长度:8位
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;// 使用普通模式,不循环
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;//中等优先级
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//存储器突发单次传输
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//外设突发单次传输
	//DMA1的数据流2
	DMA_Init(DMA_USART4_DMA_Stream, &DMA_InitStructure);//初始化DMA Stream
	DMA_Cmd(DMA_USART4_DMA_Stream, ENABLE);             //开启DMA传输,只是与前面配置不同的，注意！


	USART_Cmd(DMA_USART4, ENABLE);                    //使能串口

}

void UART5_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;//定义NVIC初始化结构体
	DMA_InitTypeDef  DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(DMA_USART5_IO_RX_CLOCK, ENABLE);
	RCC_AHB1PeriphClockCmd(DMA_USART5_IO_TX_CLOCK, ENABLE);	
	RCC_APB1PeriphClockCmd(DMA_USART5_CLOCK, ENABLE);

	GPIO_PinAFConfig(DMA_USART5_IO_RX_PORT, DMA_USART5_TX_PinSource, DMA_USART5_GPIO_AF);
	GPIO_PinAFConfig(DMA_USART5_IO_TX_PORT, DMA_USART5_RX_PinSource, DMA_USART5_GPIO_AF);

	GPIO_InitStructure.GPIO_Pin = DMA_USART5_TX | DMA_USART5_RX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//速度50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //上拉
	GPIO_Init(DMA_USART5_IO_RX_PORT, &GPIO_InitStructure);
	GPIO_Init(DMA_USART5_IO_TX_PORT, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;//波特率设置
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//收发模式
	USART_Init(DMA_USART5, &USART_InitStructure); //初始化串口

	USART_ClearFlag(DMA_USART5, USART_FLAG_TC);//清除中断标志位
	USART_ITConfig(DMA_USART5, USART_IT_IDLE, ENABLE);//开启空闲中断，串口接收数据用到了空闲中断，因此必须开启！

	USART_DMACmd(DMA_USART5, USART_DMAReq_Rx, ENABLE);  //使能串口1的DMA接收,这两句与DMA传输相关，一定要使能！！！！！！！！！！！
	USART_DMACmd(DMA_USART5, USART_DMAReq_Tx, ENABLE);  //使能串口1的DMA发送，这两句与DMA传输相关，一定要使能！！！！！！！！！！！

	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;       //串口2中断通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1; //抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority =2;	    //子优先级1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);							//根据指定的参数初始化VIC寄存器、
	
	//DMAx的各通道配置,外设到存储器
	//这里的传输形式是固定的,这点要根据不同的情况来修改
	//从存储器->外设模式/8位数据宽度/存储器增量模式
	//DMA_Streamx:DMA数据流,DMA1_Stream0~7/DMA2_Stream0~7
	//chx:DMA通道选择,@ref DMA_channel DMA_Channel_0~DMA_Channel_7
	//par:外设地址
	//mar:存储器地址
	//ndtr:数据传输量  


	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);//DMA1时钟使能 
	/* 配置 DMA Stream */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4;  //通道选择
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(DMA_USART5->DR));//DMA外设地址
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)DMA_USART5_RxBuffer;//DMA 存储器0地址
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;//外设模式到存储器！！！，这个配置很关键
	DMA_InitStructure.DMA_BufferSize = 256;//数据传输量 
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//外设非增量模式
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//存储器增量模式
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设数据长度:8位
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//存储器数据长度:8位
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;// 使用普通模式,不循环
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;//中等优先级
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//存储器突发单次传输
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//外设突发单次传输
	//DMA1的数据流2
	DMA_Init(DMA_USART5_DMA_Stream, &DMA_InitStructure);//初始化DMA Stream
	DMA_Cmd(DMA_USART5_DMA_Stream, ENABLE);             //开启DMA传输,只是与前面配置不同的，注意！


	USART_Cmd(DMA_USART5, ENABLE);                    //使能串口

}


uint32_t Serial_Pow2(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;	//设置结果初值为1
	while (Y --)			//执行Y次
	{
		Result *= X;		//将X累乘到结果
	}
	return Result;
}


void Serial_SendByte2(uint8_t Byte)
{
	USART_SendData(USART2, Byte);		//将字节数据写入数据寄存器，写入后USART自动生成时序波形
	while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);	//等待发送完成
	/*下次写入数据寄存器会自动清除发送完成标志位，故此循环后，无需清除标志位*/
}


void Serial_SendArray2(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i ++)		//遍历数组
	{
		Serial_SendByte2(Array[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}

/**
  * 函    数：串口发送一个字符串
  * 参    数：String 要发送字符串的首地址
  * 返 回 值：无
  */
void Serial_SendString2(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i ++)//遍历字符数组（字符串），遇到字符串结束标志位后停止
	{
		Serial_SendByte2(String[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}


void Serial_SendNumber2(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i ++)		//根据数字长度遍历数字的每一位
	{
		Serial_SendByte2(Number / Serial_Pow2(10, Length - i - 1) % 10 + '0');	//依次调用Serial_SendByte发送每位数字
	}
}


//struct __FILE 
//{ 
//	int handle; 
//}; 

//FILE __stdout;       
////定义_sys_exit()以避免使用半主机模式    
//void _sys_exit(int x) 
//{ 
//	x = x; 
//} 
//重定义fputc函数 
int fputc2(int ch, FILE *f)
{ 	
	while((USART2->SR&0X40)==0);//循环发送,直到发送完毕   
	USART2->DR = (u8) ch;      
	return ch;
}


uint32_t Serial_Pow3(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;	//设置结果初值为1
	while (Y --)			//执行Y次
	{
		Result *= X;		//将X累乘到结果
	}
	return Result;
}


void Serial_SendByte3(uint8_t Byte)
{
	USART_SendData(USART3, Byte);		//将字节数据写入数据寄存器，写入后USART自动生成时序波形
	while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);	//等待发送完成
	/*下次写入数据寄存器会自动清除发送完成标志位，故此循环后，无需清除标志位*/
}


void Serial_SendArray3(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i ++)		//遍历数组
	{
		Serial_SendByte3(Array[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}

/**
  * 函    数：串口发送一个字符串
  * 参    数：String 要发送字符串的首地址
  * 返 回 值：无
  */
void Serial_SendString3(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i ++)//遍历字符数组（字符串），遇到字符串结束标志位后停止
	{
		Serial_SendByte3(String[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}


void Serial_SendNumber3(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i ++)		//根据数字长度遍历数字的每一位
	{
		Serial_SendByte3(Number / Serial_Pow3(10, Length - i - 1) % 10 + '0');	//依次调用Serial_SendByte发送每位数字
	}
}





void Serial_SendByte1(uint8_t Byte)
{
	USART_SendData(USART1, Byte);		//将字节数据写入数据寄存器，写入后USART自动生成时序波形
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	//等待发送完成
	/*下次写入数据寄存器会自动清除发送完成标志位，故此循环后，无需清除标志位*/
}

void Serial_SendArray1(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i ++)		//遍历数组
	{
		Serial_SendByte1(Array[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}

/**
  * 函    数：串口发送一个字符串
  * 参    数：String 要发送字符串的首地址
  * 返 回 值：无
  */
void Serial_SendString1(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i ++)//遍历字符数组（字符串），遇到字符串结束标志位后停止
	{
		Serial_SendByte1(String[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}


void Serial_SendNumber1(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i ++)		//根据数字长度遍历数字的每一位
	{
		Serial_SendByte1(Number / Serial_Pow2(10, Length - i - 1) % 10 + '0');	//依次调用Serial_SendByte发送每位数字
	}
}


void Serial_SendByte4(uint8_t Byte)
{
	USART_SendData(UART4, Byte);		//将字节数据写入数据寄存器，写入后USART自动生成时序波形
	while (USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET);	//等待发送完成
	/*下次写入数据寄存器会自动清除发送完成标志位，故此循环后，无需清除标志位*/
}


void Serial_SendArray4(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i ++)		//遍历数组
	{
		Serial_SendByte4(Array[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}
uint8_t HWT_Tx_Data[5] = {0xFF,0xAA,0x04,0x02,0x00};

void UART4_Tx_HWT(void)
{
	Serial_SendArray4(HWT_Tx_Data,5);
}

uint8_t Camera_Tx_Data[6]={0xaa,2,0,0,0,0xbb};

/*****摄像头发送函数*****
**参数：摄像头发送数据
**作用：通过串口三进行发送
**注意：1.包头包尾，直接嵌在数组Camera_Tx_Data内部
*/

void Usart3_Tx_Cameral(uint8_t a,uint8_t b,uint8_t c,uint8_t d)
{
	Camera_Tx_Data[1] = a;
	Camera_Tx_Data[2] = b;
	Camera_Tx_Data[3] = c;
	Camera_Tx_Data[4] = d;
	
	Serial_SendArray3(Camera_Tx_Data,6);
}


//重定义fputc函数 
int fputc3(int ch, FILE *f)
{ 	
	while((USART3->SR&0X40)==0);//循环发送,直到发送完毕   
	USART3->DR = (u8) ch;      
	return ch;
}

void DMA_USART1_Data_Prase(void)
{
	uint8_t i = 0;
	if (DMA_USART1_Length >= 8)
	{
		for(i = 0;i<16;i++)
		{
			if (DMA_USART1_RxBuffer[i] == 0xa3 && DMA_USART1_RxBuffer[i+1] == 0xb3)
			{
				Ball_X=DMA_USART1_RxBuffer[i+2];
				Ball_Y=DMA_USART1_RxBuffer[i+3];
				Ball_Distence=DMA_USART1_RxBuffer[i+4];
				State_Change=DMA_USART1_RxBuffer[i+5];
				check_num = DMA_USART1_RxBuffer[i+6];
				break;
			}
		}
	}
}

void DMA_USART2_Data_Prase(void)
{
	if (DMA_USART2_Length >= 19)
	{
		
	}		

}


uint8_t check_num = 0;
uint16_t Angle_Usart = 0;
float angle = 0;

void DMA_USART3_Data_Prase(void)
{
	uint8_t i = 0;

	if (DMA_USART3_Length >= 22)
	{
		for(i = 0;i<22;i++)
		{
			if (DMA_USART3_RxBuffer[i] == 0x55 && DMA_USART3_RxBuffer[i+1] == 0x53)
			{
				Angle_Usart = DMA_USART3_RxBuffer[i+7]<<8|DMA_USART3_RxBuffer[i+6];
				if(Angle_Usart>32768)
				{
					angle = (Angle_Usart/32768.0f*180.0f-360.0f);
				}
				else
				{
					angle = Angle_Usart/32768.0f*180.0f;
				}
				break;
			}
		}
	}
}


void DMA_USART4_Data_Prase(void)
{
	if (DMA_USART4_Length == 3)
	{
		DMA_USART4_RxBuffer[0];
	}
}

static u8 RxCounter3=0;
static u32 RxBuffer3[Data_num+1]={0};
static u8 RxState = 0;	
int count=0;   
uint8_t  Ball_X = 112;
uint8_t Ball_Y,Ball_Distence,State_Change = 0;//摄像头回传数据

void DMA_USART5_Data_Prase(void)
{
}


void USART1_IRQHandler(void)                	//串口1中断服务程序
{
	if (USART_GetITStatus(DMA_USART1, USART_IT_IDLE) != RESET)//接收到一条完整数据进入空闲中断
	{
		USART_ClearITPendingBit(DMA_USART1, USART_IT_IDLE);//清除中断标志
		DMA_USART1->SR;  		DMA_USART1->DR;       //清除中断标志

		DMA_Cmd(DMA_USART1_DMA_Stream, DISABLE);                           //关闭DMA传输,此处一定要关闭，不然后面判断过不了！！！
		DMA_USART1_Length = 256 - DMA_GetCurrDataCounter(DMA_USART1_DMA_Stream);    //得到当前传输数据量
		DMA_USART1_DMA_Stream->NDTR = 256;
		DMA_Cmd(DMA_USART1_DMA_Stream, ENABLE);                            //开启DMA传输！！！！！！！！！！！
		DMA_USART1_Data_Prase();

	}
}


void USART2_IRQHandler(void)                	//串口1中断服务程序
{
	if (USART_GetITStatus(DMA_USART2, USART_IT_IDLE) != RESET)//接收到一条完整数据进入空闲中断
	{
		USART_ClearITPendingBit(DMA_USART2, USART_IT_IDLE);//清除中断标志
		DMA_USART2->SR;  		DMA_USART2->DR;       //清除中断标志

		DMA_Cmd(DMA_USART2_DMA_Stream, DISABLE);                           //关闭DMA传输,此处一定要关闭，不然后面判断过不了！！！
		DMA_USART2_Length = 256 - DMA_GetCurrDataCounter(DMA_USART2_DMA_Stream);    //得到当前传输数据量
		DMA_USART2_DMA_Stream->NDTR = 256;

		DMA_Cmd(DMA_USART2_DMA_Stream, ENABLE);                            //开启DMA传输！！！！！！！！！！！
	}
}

void USART3_IRQHandler(void)                	//串口1中断服务程序
{
	if (USART_GetITStatus(DMA_USART3, USART_IT_IDLE) != RESET)//接收到一条完整数据进入空闲中断
	{
		USART_ClearITPendingBit(DMA_USART3, USART_IT_IDLE);//清除中断标志
		DMA_USART3->SR;  		DMA_USART3->DR;       //清除中断标志

		DMA_Cmd(DMA_USART3_DMA_Stream, DISABLE);                           //关闭DMA传输,此处一定要关闭，不然后面判断过不了！！！
		DMA_USART3_Length = 256 - DMA_GetCurrDataCounter(DMA_USART3_DMA_Stream);    //得到当前传输数据量
		DMA_USART3_DMA_Stream->NDTR = 256;

		DMA_Cmd(DMA_USART3_DMA_Stream, ENABLE);                            //开启DMA传输！！！！！！！！！！！
	}
}

void UART4_IRQHandler(void)                	//串口1中断服务程序
{
	if (USART_GetITStatus(DMA_USART4, USART_IT_IDLE) != RESET)//接收到一条完整数据进入空闲中断
	{
		USART_ClearITPendingBit(DMA_USART4, USART_IT_IDLE);//清除中断标志
		DMA_USART4->SR;  		DMA_USART4->DR;       //清除中断标志

		DMA_Cmd(DMA_USART4_DMA_Stream, DISABLE);                           //关闭DMA传输,此处一定要关闭，不然后面判断过不了！！！
		DMA_USART4_Length = 256 - DMA_GetCurrDataCounter(DMA_USART4_DMA_Stream);    //得到当前传输数据量
		DMA_USART4_DMA_Stream->NDTR = 256;

		DMA_Cmd(DMA_USART4_DMA_Stream, ENABLE);                            //开启DMA传输！！！！！！！！！！！

	}
}

void UART5_IRQHandler(void)                	//串口1中断服务程序
{
	if (USART_GetITStatus(DMA_USART5, USART_IT_IDLE) != RESET)//接收到一条完整数据进入空闲中断
	{
		USART_ClearITPendingBit(DMA_USART5, USART_IT_IDLE);//清除中断标志
		DMA_USART5->SR;  		DMA_USART5->DR;       //清除中断标志

		DMA_Cmd(DMA_USART5_DMA_Stream, DISABLE);                           //关闭DMA传输,此处一定要关闭，不然后面判断过不了！！！
		DMA_USART5_Length = 256 - DMA_GetCurrDataCounter(DMA_USART5_DMA_Stream);    //得到当前传输数据量
		DMA_USART5_DMA_Stream->NDTR = 256;

		DMA_Cmd(DMA_USART5_DMA_Stream, ENABLE);                            //开启DMA传输！！！！！！！！！！！

	}
}

