#include "stm32f4xx.h"                  // Device header
#include "oled_spi.h"
#include "Key.h"
#include "Delay.h"
#include "Control.h"
#include "Flight_Parameter_Table.h"

uint8_t flash_isok = 0;

int oled_x = 0;
uint8_t Table_Index = 0;
uint8_t Change_Flag = 0;

int SDK_Step_Data[100] = {0};

void Save_SDK_Parameter(void)
{
	int16_t i = 0;

	ReadFlashParameterALL(&Table_Parameter);//�Ȱ�Ƭ���ڵ��������ݶ�������


											//����Ҫ���ĵ��ֶθ���ֵ
	Table_Parameter.Parameter_Table[0]  = SDK_Step_Data[0];
	Table_Parameter.Parameter_Table[1]  = SDK_Step_Data[1];
	Table_Parameter.Parameter_Table[2]  = SDK_Step_Data[2];
	Table_Parameter.Parameter_Table[3]  = SDK_Step_Data[3];
	Table_Parameter.Parameter_Table[4]  = SDK_Step_Data[4];
	Table_Parameter.Parameter_Table[5]  = SDK_Step_Data[5];
	Table_Parameter.Parameter_Table[6]  = SDK_Step_Data[6];
	Table_Parameter.Parameter_Table[7]  = SDK_Step_Data[7];
	Table_Parameter.Parameter_Table[8]  = SDK_Step_Data[8];
	Table_Parameter.Parameter_Table[9]  = SDK_Step_Data[9];
	Table_Parameter.Parameter_Table[10] = SDK_Step_Data[10];
	Table_Parameter.Parameter_Table[11] = SDK_Step_Data[11];
	Table_Parameter.Parameter_Table[12] = SDK_Step_Data[12];
	Table_Parameter.Parameter_Table[13] = SDK_Step_Data[13];
	Table_Parameter.Parameter_Table[14] = SDK_Step_Data[14];
	Table_Parameter.Parameter_Table[15] = SDK_Step_Data[15];
//	Table_Parameter.Parameter_Table[16] = SDK_Step_Data[16];
//	Table_Parameter.Parameter_Table[17] = SDK_Step_Data[17];
//	Table_Parameter.Parameter_Table[18] = SDK_Step_Data[18];
//	Table_Parameter.Parameter_Table[19] = SDK_Step_Data[19];
//	Table_Parameter.Parameter_Table[20] = SDK_Step_Data[20];
//	Table_Parameter.Parameter_Table[21] = SDK_Step_Data[21];
//	Table_Parameter.Parameter_Table[22] = SDK_Step_Data[22];
//	Table_Parameter.Parameter_Table[23] = SDK_Step_Data[23];
//	Table_Parameter.Parameter_Table[24] = SDK_Step_Data[24];
//	Table_Parameter.Parameter_Table[25] = SDK_Step_Data[25];
//	Table_Parameter.Parameter_Table[26] = SDK_Step_Data[26];
//	Table_Parameter.Parameter_Table[27] = SDK_Step_Data[27];
//	Table_Parameter.Parameter_Table[28] = SDK_Step_Data[28];
//	Table_Parameter.Parameter_Table[29] = SDK_Step_Data[29];
//	Table_Parameter.Parameter_Table[30] = SDK_Step_Data[30];
//	Table_Parameter.Parameter_Table[31] = SDK_Step_Data[31];
//	Table_Parameter.Parameter_Table[32] = SDK_Step_Data[32];
//	Table_Parameter.Parameter_Table[33] = SDK_Step_Data[33];
//	Table_Parameter.Parameter_Table[34] = SDK_Step_Data[34];
//	Table_Parameter.Parameter_Table[35] = SDK_Step_Data[35];
//	Table_Parameter.Parameter_Table[36] = SDK_Step_Data[36];
//	Table_Parameter.Parameter_Table[37] = SDK_Step_Data[37];
//	Table_Parameter.Parameter_Table[38] = SDK_Step_Data[38];
//	Table_Parameter.Parameter_Table[39] = SDK_Step_Data[39];
//	Table_Parameter.Parameter_Table[40] = SDK_Step_Data[40];
//	Table_Parameter.Parameter_Table[41] = SDK_Step_Data[41];
//	Table_Parameter.Parameter_Table[42] = SDK_Step_Data[42];
//	Table_Parameter.Parameter_Table[43] = SDK_Step_Data[43];
//	Table_Parameter.Parameter_Table[44] = SDK_Step_Data[44];
//	Table_Parameter.Parameter_Table[45] = SDK_Step_Data[45];
//	Table_Parameter.Parameter_Table[46] = SDK_Step_Data[46];
//	Table_Parameter.Parameter_Table[47] = SDK_Step_Data[47];
//	Table_Parameter.Parameter_Table[48] = SDK_Step_Data[48];
//	Table_Parameter.Parameter_Table[49] = SDK_Step_Data[49];
//	Table_Parameter.Parameter_Table[50] = SDK_Step_Data[50];
//	Table_Parameter.Parameter_Table[51] = SDK_Step_Data[51];
//	Table_Parameter.Parameter_Table[52] = SDK_Step_Data[52];
//	Table_Parameter.Parameter_Table[53] = SDK_Step_Data[53];
//	Table_Parameter.Parameter_Table[54] = SDK_Step_Data[54];
//	Table_Parameter.Parameter_Table[55] = SDK_Step_Data[55];
//	Table_Parameter.Parameter_Table[56] = SDK_Step_Data[56];
//	Table_Parameter.Parameter_Table[57] = SDK_Step_Data[57];
//	Table_Parameter.Parameter_Table[58] = SDK_Step_Data[58];
//	Table_Parameter.Parameter_Table[59] = SDK_Step_Data[59];
//	Table_Parameter.Parameter_Table[60] = SDK_Step_Data[60];
//	Table_Parameter.Parameter_Table[61] = SDK_Step_Data[61];
//	Table_Parameter.Parameter_Table[62] = SDK_Step_Data[62];
//	Table_Parameter.Parameter_Table[63] = SDK_Step_Data[63];
//	Table_Parameter.Parameter_Table[64] = SDK_Step_Data[64];
//	Table_Parameter.Parameter_Table[65] = SDK_Step_Data[65];
//	Table_Parameter.Parameter_Table[66] = SDK_Step_Data[66];
//	Table_Parameter.Parameter_Table[67] = SDK_Step_Data[67];
//	Table_Parameter.Parameter_Table[68] = SDK_Step_Data[68];
//	Table_Parameter.Parameter_Table[69] = SDK_Step_Data[69];
//	Table_Parameter.Parameter_Table[70] = SDK_Step_Data[70];
//	Table_Parameter.Parameter_Table[71] = SDK_Step_Data[71];


	
//	Table_Parameter.Parameter_Table[130] = flash_isok;

	FLASH_Unlock();								//���� 
	FLASH_DataCacheCmd(DISABLE);				//FLASH�����ڼ�,�����ֹ���ݻ���
	Parameter_Table_FLASHStatus = FLASH_EraseSector(STMFLASH_GetFlashSector(PARAMETER_TABLE_STARTADDR), VoltageRange_3);
	if (Parameter_Table_FLASHStatus == FLASH_COMPLETE)
	{
		for (i = 0; i < FLIGHT_PARAMETER_TABLE_NUM; i++)
		{
			Parameter_Table_FLASHStatus = FLASH_ProgramWord(PARAMETER_TABLE_STARTADDR + 4 * i, *(uint32_t *)(&Table_Parameter.Parameter_Table[i]));
		}
	}
	FLASH_DataCacheCmd(ENABLE);	//FLASH��������,�������ݻ���
	FLASH_Lock();//����
}

void Load_saved_sdk_parament(void)
{
	ReadFlashParameterALL(&Table_Parameter);//�Ȱ�Ƭ���ڵ��������ݶ�������
	
	SDK_Step_Data[0] 		 =	Table_Parameter.Parameter_Table[0] ;
	SDK_Step_Data[1] 		 = 	Table_Parameter.Parameter_Table[1] ;
	SDK_Step_Data[2] 		 = 	Table_Parameter.Parameter_Table[2] ;
	SDK_Step_Data[3] 		 = 	Table_Parameter.Parameter_Table[3] ;
	SDK_Step_Data[4] 		 = 	Table_Parameter.Parameter_Table[4] ;
	SDK_Step_Data[5] 		 = 	Table_Parameter.Parameter_Table[5] ;
	SDK_Step_Data[6] 		 = 	Table_Parameter.Parameter_Table[6] ;
	SDK_Step_Data[7] 		 = 	Table_Parameter.Parameter_Table[7] ;
	SDK_Step_Data[8] 		 = 	Table_Parameter.Parameter_Table[8] ;
	SDK_Step_Data[9] 		 = 	Table_Parameter.Parameter_Table[9] ;
	SDK_Step_Data[10] 		 = 	Table_Parameter.Parameter_Table[10];
	SDK_Step_Data[11] 		 = 	Table_Parameter.Parameter_Table[11];
	SDK_Step_Data[12] 		 = 	Table_Parameter.Parameter_Table[12];
	SDK_Step_Data[13] 		 = 	Table_Parameter.Parameter_Table[13];
	SDK_Step_Data[14] 		 = 	Table_Parameter.Parameter_Table[14];
	SDK_Step_Data[15] 		 = 	Table_Parameter.Parameter_Table[15];
	//SDK_Step_Data[16] 		 = 	Table_Parameter.Parameter_Table[16];
	//SDK_Step_Data[17] 		 = 	Table_Parameter.Parameter_Table[17];
	//SDK_Step_Data[18] 		 = 	Table_Parameter.Parameter_Table[18];
	//SDK_Step_Data[19] 		 = 	Table_Parameter.Parameter_Table[19];
	//SDK_Step_Data[20] 		 = 	Table_Parameter.Parameter_Table[20];
	//SDK_Step_Data[21] 		 = 	Table_Parameter.Parameter_Table[21];
	//SDK_Step_Data[22] 		 = 	Table_Parameter.Parameter_Table[22];
	//SDK_Step_Data[23] 		 = 	Table_Parameter.Parameter_Table[23];
	//SDK_Step_Data[24] 		 = 	Table_Parameter.Parameter_Table[24];
	//SDK_Step_Data[25] 		 = 	Table_Parameter.Parameter_Table[25];
	//SDK_Step_Data[26] 		 = 	Table_Parameter.Parameter_Table[26];
	//SDK_Step_Data[27] 		 = 	Table_Parameter.Parameter_Table[27];
	//SDK_Step_Data[28] 		 = 	Table_Parameter.Parameter_Table[28];
	//SDK_Step_Data[29] 		 = 	Table_Parameter.Parameter_Table[29];
	//Servo1_Catch_Open 		 = 	Table_Parameter.Parameter_Table[30];
	//Servo1_Catch_Close 		 = 	Table_Parameter.Parameter_Table[31];
	//Servo1_Catch_Openlittle  = 	Table_Parameter.Parameter_Table[32];
	//Servo2_Wuliao1 			 = 	Table_Parameter.Parameter_Table[33];
	//Servo2_Wuliao2 			 = 	Table_Parameter.Parameter_Table[34];
	//Servo2_Wuliao3 			 = 	Table_Parameter.Parameter_Table[35];
	//Servo3_Turn_OutSide 	 = 	Table_Parameter.Parameter_Table[36];
	//Servo3_Turn_InSide 		 = 	Table_Parameter.Parameter_Table[37];
	//Servo_Speed 			 = 	Table_Parameter.Parameter_Table[38];
	//Servo_Speed2 			 = 	Table_Parameter.Parameter_Table[39];
	//LIFT_Turn_POS 			 = 	Table_Parameter.Parameter_Table[40];
	//LIFT_Put_POS 			 = 	Table_Parameter.Parameter_Table[41];
	//LIFT_Catch_POS 			 = 	Table_Parameter.Parameter_Table[42];
	//LIFT_Put_ONkuai_POS 	 = 	Table_Parameter.Parameter_Table[43];
	//LIFT_Put_Ground_POS 	 = 	Table_Parameter.Parameter_Table[44];
	//LIFT_Find_Catch_Kuai 	 = 	Table_Parameter.Parameter_Table[45];
	//Servo_Speed_ffast 		 = 	Table_Parameter.Parameter_Table[46];
	//Servo_Speed_fast 		 = 	Table_Parameter.Parameter_Table[47];
	//Servo_Speed_middle 		 = 	Table_Parameter.Parameter_Table[48];
	//Servo_Speed_slow 		 = 	Table_Parameter.Parameter_Table[49];
	//Servo_Speed_put 		 = 	Table_Parameter.Parameter_Table[50];
	//R_RANGE 				 = 	Table_Parameter.Parameter_Table[51];
	//R_RANGE_SCAL			 =  Table_Parameter.Parameter_Table[52];
	//Dis_MIN					 =  Table_Parameter.Parameter_Table[53];

	//Life_speed 				 =	Table_Parameter.Parameter_Table[54];
	//Yaw_Control_OutPut_define=	Table_Parameter.Parameter_Table[55];
	//test_speed5 			 =	Table_Parameter.Parameter_Table[56];
	//Car_FBLR_ERR_Range 		 =	Table_Parameter.Parameter_Table[57];
	//Car_FB_PIDOut_MAX 		 =	Table_Parameter.Parameter_Table[58];
	//Car_LR_PIDOut_MAX		 =	Table_Parameter.Parameter_Table[59];
	//Motor_speed_UP_Max		 =	Table_Parameter.Parameter_Table[60];
	//Motor_speed_UP2			 =	Table_Parameter.Parameter_Table[61];
	//Motor_speed_UP			 =	Table_Parameter.Parameter_Table[62];
	//Y_Center                 =  Table_Parameter.Parameter_Table[63];
	//X_Center                 =  Table_Parameter.Parameter_Table[64];
	//LIFT_Take_POS            =  Table_Parameter.Parameter_Table[65];

 //   huai_xoff				 =  Table_Parameter.Parameter_Table[66];
 //   huai_xoffrange			 = 	Table_Parameter.Parameter_Table[67];
 //   huai_yoff				 = 	Table_Parameter.Parameter_Table[68];
 //   huai_yoffrange			 = 	Table_Parameter.Parameter_Table[69];
	//HUan_R_RANGE			 =  Table_Parameter.Parameter_Table[70];
	//flash_isok				 =  Table_Parameter.Parameter_Table[130];
	//Lightenable = Table_Parameter.Parameter_Table[71];

//	Sensor.P               =       Table_Parameter.Parameter_Table[33];  
//	Sensor.P_Out_Max       =       Table_Parameter.Parameter_Table[34];  
//	Sensor.I               =       Table_Parameter.Parameter_Table[35];  
//	Sensor.I_Out_Max       =       Table_Parameter.Parameter_Table[36];  
//	Sensor.D               =       Table_Parameter.Parameter_Table[37];  
//	Sensor.D_Out_Max       =       Table_Parameter.Parameter_Table[38];  
//	Sensor.Output_max      =       Table_Parameter.Parameter_Table[39];  
//	sTrack.P               =       Table_Parameter.Parameter_Table[40];  
//	sTrack.P_Out_Max       =       Table_Parameter.Parameter_Table[41];  
//	sTrack.I               =       Table_Parameter.Parameter_Table[42];  
//	sTrack.I_Out_Max       =       Table_Parameter.Parameter_Table[43];  
//	sTrack.D               =       Table_Parameter.Parameter_Table[44];  
//	sTrack.D_Out_Max       =       Table_Parameter.Parameter_Table[45];  
//	sTrack.Output_max      =       Table_Parameter.Parameter_Table[46];  
//	Car_L_Out_menu         =       Table_Parameter.Parameter_Table[47];  
//	Car_R_Out_menu         =       Table_Parameter.Parameter_Table[48]; 
	                    											  

}
void Page0(void);
void Page1_0(void);
void Page1_1(void);
void Page1_2(void);
void Page1_3(void);
void Page1_4(void);
void Page1_5(void);
void Page1_6(void);
void Page1_7(void);
void Page1_8(void);
void Page1_9(void);
void Page1_10(void);
void Page1_11(void);
void Page1_12(void);
void Page1_13(void);
void Page1_14(void);
void Page1_15(void);
void Page1_16(void);

typedef struct
{
	uint32_t Index;//����
	uint8_t Up;//����
	uint8_t Down;//����
	uint8_t Enter;//����
	uint8_t Back;
	void (*current_operation)(void);//	��ǰ����ִ�еĺ���(����)
}Menu_table;

enum 
{
	up = 1,
	down , 
	enter,
	back
};

enum
{
	page0,
	page1_0,page1_1,page1_2,page1_3,page1_4,page1_5,page1_6,page1_7,page1_8,page1_9,page1_10,page1_11,page1_12,
	page1_13,page1_14,page1_15,page1_16,
};                                
               
              

Menu_table task[]={
	//����	��һ��		��һ��		��һҳ		��һҳ		��ǰ������ʾ����
	{page0,page1_0,page1_0,page1_0,page1_0,Page0},		
	{page1_0,page1_16,page1_1,page1_0,page1_0,Page1_0},	
	{page1_1,page1_0,page1_2,page1_1,page1_1,Page1_1},	
	{page1_2,page1_1,page1_3,page1_2,page1_2,Page1_2},	
	{page1_3,page1_2,page1_4,page1_3,page1_3,Page1_3},	
	{page1_4,page1_3,page1_5,page1_4,page1_4,Page1_4},	
	{page1_5,page1_4,page1_6,page1_5,page1_5,Page1_5},	
	{page1_6,page1_5,page1_7,page1_6,page1_6,Page1_6},	
	{page1_7,page1_6,page1_8,page1_7,page1_7,Page1_7},	
	{page1_8,page1_7,page1_9,page1_8,page1_8,Page1_8},	
	{page1_9,page1_8,page1_10,page1_9,page1_9,Page1_9},	
	{page1_10,page1_9,page1_11,page1_10,page1_10,Page1_10},
	{page1_11,page1_10,page1_12,page1_11,page1_11,Page1_11},
	{page1_12,page1_11,page1_13,page1_12,page1_12,Page1_12},
	{page1_13,page1_12,page1_14,page1_13,page1_13,Page1_13},
	{page1_14,page1_13,page1_15,page1_14,page1_14,Page1_14},
	{page1_15,page1_14,page1_16,page1_15,page1_15,Page1_15},
	{page1_16,page1_15,page1_0,page1_16,page1_16,Page1_16},
	
};



void Page_Saving(void)
{
	// LCD_ShowString(5,140, 80,20,16,BLACK,"Saving");
	OLED_ShowString(2,5,"SAVING",12);

}

void Page0(void)
{
	
}

void Page1_0(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,RED,"IMU");		LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				// LCD_ShowString(5,  5, 80,20,16,RED,"IMU");		LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	

				if(KeyNum == up) SDK_Step_Data[0]++;
				if(KeyNum == down) SDK_Step_Data[0]--;
				if(KeyNum == back) break;
				
			}
		}
}

void Page1_1(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,RED,"PID");    LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
		// LCD_ShowString(5, 20, 80,20,16,RED,"PID");    LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
				if(KeyNum == up) SDK_Step_Data[1]++;
				if(KeyNum == down)	SDK_Step_Data[1]--;
				if(KeyNum == back) break;
	
			}
		}
	
}

void Page1_2(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,RED,"PID0");   LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[2]++;
				if(KeyNum == down)	SDK_Step_Data[2]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5, 40, 80,20,16,RED,"PID0");   LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
			}
		}
		
	
}

void Page1_3(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,RED,"PID1");   LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[3]++;
				if(KeyNum == down)	SDK_Step_Data[3]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5, 60, 80,20,16,RED,"PID1");   LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
			}
		}
	
}

void Page1_4(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,RED,"PID2");   LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[4]++;
				if(KeyNum == down)	SDK_Step_Data[4]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5, 80, 80,20,16,RED,"PID2");   LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
			}
		}
	
}

void Page1_5(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,RED,"PID3");   LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[5]++;
				if(KeyNum == down)	SDK_Step_Data[5]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,100, 80,20,16,RED,"PID3");   LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
			}
		}
	
}

void Page1_6(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,RED,"PID4");   LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[6]++;
				if(KeyNum == down)	SDK_Step_Data[6]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,120, 80,20,16,RED,"PID4");   LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
			}
		}
	
}

void Page1_7(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,RED,"PID5");   LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[7]++;
				if(KeyNum == down)	SDK_Step_Data[7]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,140, 80,20,16,RED,"PID5");   LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
			}
		}
	
}

void Page1_8(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,RED,"PID6");   LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[8]++;
				if(KeyNum == down)	SDK_Step_Data[8]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,160, 80,20,16,RED,"PID6");   LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
			}
		}
	
}
void Page1_9(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,RED,"PID7");   LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[9]++;
				if(KeyNum == down)	SDK_Step_Data[9]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,180, 80,20,16,RED,"PID7");   LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
			}
		}
	
}
void Page1_10(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,RED,"PID8");   LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[10]++;
				if(KeyNum == down)	SDK_Step_Data[10]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,200, 80,20,16,RED,"PID8");   LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
			}
		}
	
}
void Page1_11(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,RED,"PID9");   LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);			
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[11]++;
				if(KeyNum == down)	SDK_Step_Data[11]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,220, 80,20,16,RED,"PID9");   LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
			}
		}

}
void Page1_12(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,RED,"PID11");  LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[12]++;
				if(KeyNum == down)	SDK_Step_Data[12]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,240, 80,20,16,RED,"PID11");  LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
			}
		}
	
}

void Page1_13(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,RED,"PID12");  LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[13]++;
				if(KeyNum == down)	SDK_Step_Data[13]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,260, 80,20,16,RED,"PID12");  LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
			}
		}
	
}

void Page1_14(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,RED,"PID13");  LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);		
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[14]++;
				if(KeyNum == down)	SDK_Step_Data[14]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,280, 80,20,16,RED,"PID13");  LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
			}
		}
	
}

void Page1_15(void)
{		
		// LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
		// LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
		// LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
		// LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
		// LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
		// LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
		// LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
		// LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
		// LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
		// LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
		// LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
		// LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
		// LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
		// LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
		// LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
		// LCD_ShowString(5,300, 80,20,16,RED,"PID14");	LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);				
		// LCD_ShowString(200,300,80,20,16,BLACK,"SAVE");
		if(KeyNum == enter) 
		{
			while(1)
			{
				KeyNum = 5;
				Key_Scan();
				if(KeyNum == up) SDK_Step_Data[15]++;
				if(KeyNum == down)	SDK_Step_Data[15]--;
				if(KeyNum == back) break;
		// LCD_ShowString(5,300, 80,20,16,RED,"PID14");	LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);				
			}
		}

}

void Page1_16(void)
{		
// 		LCD_ShowString(5,  5, 80,20,16,BLACK,"IMU");	LCD_ShowNum(80,  5,SDK_Step_Data[ 0],3,16,BLACK);	
// 		LCD_ShowString(5, 20, 80,20,16,BLACK,"PID");  LCD_ShowNum(80, 20,SDK_Step_Data[ 1],3,16,BLACK);	
// 		LCD_ShowString(5, 40, 80,20,16,BLACK,"PID0"); LCD_ShowNum(80, 40,SDK_Step_Data[ 2],3,16,BLACK);	
// 		LCD_ShowString(5, 60, 80,20,16,BLACK,"PID1"); LCD_ShowNum(80, 60,SDK_Step_Data[ 3],3,16,BLACK);	
// 		LCD_ShowString(5, 80, 80,20,16,BLACK,"PID2"); LCD_ShowNum(80, 80,SDK_Step_Data[ 4],3,16,BLACK);	
// 		LCD_ShowString(5,100, 80,20,16,BLACK,"PID3"); LCD_ShowNum(80,100,SDK_Step_Data[ 5],3,16,BLACK);	
// 		LCD_ShowString(5,120, 80,20,16,BLACK,"PID4"); LCD_ShowNum(80,120,SDK_Step_Data[ 6],3,16,BLACK);	
// 		LCD_ShowString(5,140, 80,20,16,BLACK,"PID5"); LCD_ShowNum(80,140,SDK_Step_Data[ 7],3,16,BLACK);	
// 		LCD_ShowString(5,160, 80,20,16,BLACK,"PID6"); LCD_ShowNum(80,160,SDK_Step_Data[ 8],3,16,BLACK);	
// 		LCD_ShowString(5,180, 80,20,16,BLACK,"PID7"); LCD_ShowNum(80,180,SDK_Step_Data[ 9],3,16,BLACK);	
// 		LCD_ShowString(5,200, 80,20,16,BLACK,"PID8"); LCD_ShowNum(80,200,SDK_Step_Data[10],3,16,BLACK);	
// 		LCD_ShowString(5,220, 80,20,16,BLACK,"PID9"); LCD_ShowNum(80,220,SDK_Step_Data[11],3,16,BLACK);	
// 		LCD_ShowString(5,240, 80,20,16,BLACK,"PID11");LCD_ShowNum(80,240,SDK_Step_Data[12],3,16,BLACK);	
// 		LCD_ShowString(5,260, 80,20,16,BLACK,"PID12");LCD_ShowNum(80,260,SDK_Step_Data[13],3,16,BLACK);	
// 		LCD_ShowString(5,280, 80,20,16,BLACK,"PID13");LCD_ShowNum(80,280,SDK_Step_Data[14],3,16,BLACK);	
// 		LCD_ShowString(5,300, 80,20,16,BLACK,"PID14");LCD_ShowNum(80,300,SDK_Step_Data[15],3,16,BLACK);					
// 		LCD_ShowString(200,300,80,20,16,RED,"SAVE");
		
		if(KeyNum == enter)
		{
			while(1)
			{
				KeyNum = 5;
				
				Key_Scan();
				if(KeyNum == enter)
				{
					// LCD_Clear(WHITE);

					// LCD_ShowString(5,140, 80,20,16,BLACK,"Saving");
								
					Save_SDK_Parameter();			
					// LCD_Clear(WHITE);	
				}
				if(KeyNum == back) break;
			}				
		}			
}



void Menu_Table(void)
{
	task[Table_Index].current_operation();

	if(task[Table_Index].Index == 0)
	{
		if(KeyNum == up || KeyNum == down || KeyNum == enter || KeyNum == back)
		{
			Table_Index = 1;
			Change_Flag = 1;
			KeyNum = 5;
		}
	}
	if(KeyNum == up)
	{
		KeyNum = 5;
		Table_Index = task[Table_Index].Up;
		Change_Flag = 1;
	}
	if(KeyNum == down)
	{
		KeyNum = 5;
		Table_Index = task[Table_Index].Down;
		Change_Flag = 1;
	}
	if(KeyNum == enter)
	{
		KeyNum = 5;
		Table_Index = task[Table_Index].Enter;
		Change_Flag = 1;
	}
	if(KeyNum == back)
	{
		KeyNum = 5;
		Table_Index = task[Table_Index].Back;
		Change_Flag = 1;
	}
}
