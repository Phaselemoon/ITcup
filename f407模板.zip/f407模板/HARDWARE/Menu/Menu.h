#ifndef __MENU_H
#define __MENU_H
#include "stm32f4xx.h"                  // Device header
#include "sys.h"


extern int SDK_Step_Data[100];

//uint8_t flash_isok;

extern int16_t Page_Number;
extern int My_page_number;
extern uint8_t key_flag;
extern int Page_Danger_Data2;

void Load_saved_sdk_parament(void);
void Save_SDK_Parameter(void);

void Page1(void);

void Menu_Table(void);

#endif
