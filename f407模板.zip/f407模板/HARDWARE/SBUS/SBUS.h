#ifndef __SBUS_H
#define __SBUS_H

#include "stm32f4xx.h"                  // Device header
#include <stdarg.h>
#include <stdio.h>


void SBUS_RECEIVE(uint8_t *buf);
extern uint32_t CH[16];


#endif
