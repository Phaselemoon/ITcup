#ifndef __Gray_H
#define __Gray_H

void Gray_init(void);
void Get_Gray_State(void);

#define 	L3 		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_0)
#define 	L2 		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_1)
#define 	L1 		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_2)
#define 	M0 		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_3)
#define 	R1 		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_4)
#define 	R2 		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_5)
#define 	R3 		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_6)

extern int Line_Num;
extern int Line_Speed;
extern int T_Flag;
extern int STOP_Flag;
extern int Right_Flag;
extern int Left_Flag;
//extern volatile uint32_t Spin_cnt;
extern int curspeed;


#endif
