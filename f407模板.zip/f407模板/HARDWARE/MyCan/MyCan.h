#ifndef __MYCAN_H
#define __MYCAN_H
#include "stm32f4xx.h"                  // Device header
#include <stdbool.h>

typedef struct {
	__IO CanRxMsg CAN_RxMsg;
	__IO CanTxMsg CAN_TxMsg;

	__IO bool rxFrameFlag;
}CAN_t;

void can_SendCmd(__IO uint8_t *cmd, uint8_t len);

extern __IO CAN_t can;

void MyCan_Init(void);


#endif
